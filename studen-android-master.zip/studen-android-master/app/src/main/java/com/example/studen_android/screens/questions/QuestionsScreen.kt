package com.example.studen_android.screens.questions

import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun QuestionsScreen(

) {
    Text(text = "Native part")
}